package edu.sau.zelihacakin.rastgelekisiuret;

import edu.sau.zelihacakin.rastgelekisiuret.util.TelNoUretici;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* Her telefona bir İmei no üretme fonksiyonunu çağırır
* </p>
*/
public class Telefon {
	private String telNo;
	private IMEINo imeiNo;

	public Telefon() {
		this.telNo = TelNoUretici.telnoUret();
		this.imeiNo = new IMEINo();
	}

	public String getTelNo() {
		return telNo;
	}

	public IMEINo getImeiNo() {
		return imeiNo;
	}

}
