package edu.sau.zelihacakin.rastgelekisiuret;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* Rastgele oluşturulan tüm özellikleri rastgele kişi üreterek çağırır
* </p>
*/
public class RastgeleKisi {
	public Kisi rastgeleKisiUret() {
		Kisi k = new Kisi();
		System.out.println(k.getKimlikNo().getTcKimlikNo() + " " + k.getIsim() + " " + k.getSoyisim() + " " + k.getYas()
				+ " " + k.getTelefon().getTelNo() + " (" + k.getTelefon().getImeiNo().getImeiNo() + ")");
		return k;
	}
}
