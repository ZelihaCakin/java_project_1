package edu.sau.zelihacakin.rastgelekisiuret;

import edu.sau.zelihacakin.rastgelekisiuret.util.IsimSoyisimSecici;
import edu.sau.zelihacakin.rastgelekisiuret.util.YasUretici;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* Kişiye ait özellikleri çağırır
* </p>
*/
public class Kisi {
	private String isim;
	private String soyisim;
	private int yas;
	private Telefon telefon;
	private KimlikNo kimlikNo;
	
	public Kisi() {
		this.isim=IsimSoyisimSecici.rastgeleIsim();
		this.soyisim=IsimSoyisimSecici.rastgeleSoyisim();
		this.yas=YasUretici.yasUret();
		this.telefon=new Telefon();
		this.kimlikNo=new KimlikNo();
		
	}
	public String getIsim() {
		return isim;
	}
	
	public String getSoyisim() {
		return soyisim;
	}
	
	public int getYas() {
		return yas;
	}
	
	public Telefon getTelefon() {
		return telefon;
	}
	
	public KimlikNo getKimlikNo() {
		return kimlikNo;
	}
	
}
