package edu.sau.zelihacakin.rastgelekisiuret.util;

import java.util.Random;
import java.util.function.BiConsumer;

import org.w3c.dom.ls.LSOutput;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* İmei numaralarını Luhn algoritmasıyla rastgele üretme kuralını ve kontrolünü içerir
* </p>
*/
public class IMEIUretici {
	public static String imeiUret() {
		Random random = new Random();
		long pivot = random.nextLong((99999999999999L - 10000000000000L) + 1) + 10000000000000L;

		String pivotString = String.valueOf(pivot);
		char[] arr = pivotString.toCharArray();

		int tekBasamaklarToplami = 0;
		int ciftBasmaklarToplami = 0;
		int tumBasamaklarToplami = 0;
		int toplam = 0;

		for (int i = 0; i < arr.length; i++) {
			int deger = Integer.valueOf(String.valueOf(arr[i]));
			if (i % 2 == 0) {
				tekBasamaklarToplami += deger;
			} else {
				int tmp = deger * 2;
				if (tmp > 9) {
					char[] q = String.valueOf(tmp).toCharArray();
					toplam = Integer.valueOf(String.valueOf(q[0])) + Integer.valueOf(String.valueOf(q[1]));
				} else {
					toplam = tmp;
				}
				ciftBasmaklarToplami += toplam;
			}
		}

		tumBasamaklarToplami += tekBasamaklarToplami + ciftBasmaklarToplami;

		Integer onBesinciBasamak = (10 - (tumBasamaklarToplami % 10)) % 10;

		String imei = pivotString.concat(onBesinciBasamak.toString());
		if (imeiKontrolEt(imei)) {
			return imei;
		} else {
			return null;
		}
	}

	public static boolean imeiKontrolEt(String imeiNo) {
		String pivotString = imeiNo.substring(0, 14);
		char[] arr = pivotString.toCharArray();

		int tekBasamaklarToplami = 0;
		int ciftBasmaklarToplami = 0;
		int tumBasamaklarToplami = 0;
		int toplam = 0;

		for (int i = 0; i < arr.length; i++) {
			int deger = Integer.valueOf(String.valueOf(arr[i]));
			if (i % 2 == 0) {
				tekBasamaklarToplami += deger;
			} else {
				int tmp = deger * 2;
				if (tmp > 9) {
					char[] q = String.valueOf(tmp).toCharArray();
					toplam = Integer.valueOf(String.valueOf(q[0])) + Integer.valueOf(String.valueOf(q[1]));
				} else {
					toplam = tmp;
				}
				ciftBasmaklarToplami += toplam;
			}
		}

		tumBasamaklarToplami = tekBasamaklarToplami + ciftBasmaklarToplami;

		Integer onBesinciBasamak = (10 - (tumBasamaklarToplami % 10)) % 10;

		boolean result;
		if (imeiNo.length() == 15) {
			result = true;
		} else {
			result = false;
		}

		if (onBesinciBasamak.toString().equals(String.valueOf(imeiNo.charAt(14)))) {
			result = true;
		} else {
			result = false;
		}

		return result;

	}

//	public static void main(String[] args) {
//		String imeiString = imeiUret();
//		System.out.println(imeiString);
//		System.out.println(imeiKontrolEt(imeiString));
//	}

}
