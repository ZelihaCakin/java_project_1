package edu.sau.zelihacakin.rastgelekisiuret.util;

import java.util.Random;

import edu.sau.zelihacakin.rastgelekisiuret.KimlikNo;
import edu.sau.zelihacakin.rastgelekisiuret.Kisi;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* 0 ile 100 arasında rastgele yaş üretme kuralını içerir
* </p>
*/
public class YasUretici {

	public static int yasUret() {
		Random random = new Random();
		return random.nextInt((100 - 0) + 1) + 0;
	}
	
}
