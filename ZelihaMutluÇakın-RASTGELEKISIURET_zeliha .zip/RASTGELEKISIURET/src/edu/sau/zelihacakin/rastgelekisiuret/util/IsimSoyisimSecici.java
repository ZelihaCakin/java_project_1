package edu.sau.zelihacakin.rastgelekisiuret.util;

import java.util.Random;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* İsim ve soyisimleri rastgele üretme kuralını içerir
* </p>
*/
public class IsimSoyisimSecici {
	private static String[] insanIsimleri = { "Çağatay", "Selçuk", "Ahmet", "Mehmet", "Ali", "Ayşe", "Fatma", "Mustafa", "Zeynep", "Serkan",
			"İbrahim", "Şule", "Deniz", "Ceren", "Özge", "Can", "Burak", "Emre", "Gamze", "Gülnur", "Gülşah", "Hakan",
			"İpek", "İsmet", "Kadir", "Kaan", "Kerem", "Leyla", "Melek", "Murat", "Nalan", "Nil", "Nuri", "Okan",
			"Pınar", "Rıdvan", "Selin", "Tahir", "Talha", "Tuğçe", "Uğur", "Yakup", "Yasemin", "Yavuz", "Yıldız",
			"Yusuf", "Zafer", "Zehra", "Zeki", "Zerrin" };
	private static String[] soyisimler = { "Yılmaz", "Kaya", "Demir", "Öztürk", "Şahin", "Aksoy", "Güler", "Koç",
			"Karakaş", "Sarı", "Kılıç", "Toprak", "Erdoğan", "Türk", "Aydın", "Çelik", "Bayram", "Akbaba", "Bulut",
			"Erten", "Şener", "Erdem", "Koşar", "Köse", "Güven", "Aslan", "Kara", "Acar", "Kurt", "Aktaş", "Balcı",
			"Özdemir", "Gündoğdu", "Karaman", "Güney", "Çetin", "Başar", "Çoban", "Şimşek", "Durmaz", "Uzun", "Doğan",
			"Akyüz", "Yalçın", "Akman", "Keskin", "Sönmez", "Sözen", "Gürsoy", "Yıldırım" };

	public static String rastgeleIsim() {
		return insanIsimleri[sayiUret()];
	}

	public static String rastgeleSoyisim() {
		return soyisimler[sayiUret()];
	}

	private static int sayiUret() {
		Random random = new Random();
		return random.nextInt((49 - 0) + 1);
	}

}
