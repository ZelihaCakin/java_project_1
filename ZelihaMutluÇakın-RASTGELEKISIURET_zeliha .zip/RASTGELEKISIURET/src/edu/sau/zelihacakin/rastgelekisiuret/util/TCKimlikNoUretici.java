package edu.sau.zelihacakin.rastgelekisiuret.util;

import java.util.Iterator;
import java.util.Random;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* T.C kimlik no üretme kuralına uygun olarak üretme kuralını ve kontrolünü içerir
* </p>
*/
public class TCKimlikNoUretici {
	public static String tcKimlikNoUret() {
		Random random = new Random();
		int pivot = random.nextInt((999999999 - 100000000) + 1) + 100000000;
		
		String pivotString = String.valueOf(pivot);
		char[] arr = pivotString.toCharArray();
		
		int tekBasamaklarToplami = 0;
		int ciftBasmaklarToplami = 0;
		int tumBasamaklarToplami =0;
		
		for (int i=0;i<arr.length;i++) {
			int deger = Integer.valueOf(String.valueOf(arr[i]));
			if(i%2==0) {
				tekBasamaklarToplami += deger;
			} else {
				ciftBasmaklarToplami += deger;
			}
			tumBasamaklarToplami += deger;
		}
		
		Integer onuncuBasamak = ((tekBasamaklarToplami * 7) - ciftBasmaklarToplami) % 10;
		Integer onbirinciBasamak = (tumBasamaklarToplami + onuncuBasamak) % 10;
		
		String tckn = pivotString.concat(onuncuBasamak.toString()).concat(onbirinciBasamak.toString());
		if (tcKimlikKontrolEt(tckn)) {
			return tckn;
		} else {
			return null;
		}
	}
	
	public static boolean tcKimlikKontrolEt(String tcKimlikNo) {
		String pivotString = tcKimlikNo.substring(0,9);
		char[] arr = pivotString.toCharArray();
		
		int tekBasamaklarToplami = 0;
		int ciftBasmaklarToplami = 0;
		int tumBasamaklarToplami =0;
		
		for (int i=0;i<arr.length;i++) {
			int deger = Integer.valueOf(String.valueOf(arr[i]));
			if(i%2==0) {
				tekBasamaklarToplami += deger;
			} else {
				ciftBasmaklarToplami += deger;
			}
			tumBasamaklarToplami += deger;
		}
		
		Integer onuncuBasamak = ((tekBasamaklarToplami * 7) - ciftBasmaklarToplami) % 10;
		Integer onbirinciBasamak = (tumBasamaklarToplami + onuncuBasamak) % 10;
		
		boolean result;
		if (tcKimlikNo.length() == 11) {
			result = true;
		} else {
			result = false;
		}
		
		if (!"0".equals(String.valueOf(tcKimlikNo.charAt(0)))) {
			result = true;
		} else {
			result = false;
		}
		
		if (onuncuBasamak.toString().equals(String.valueOf(tcKimlikNo.charAt(9)))) {
			result = true;
		} else {
			result = false;
		}
		
		if (onbirinciBasamak.toString().equals(String.valueOf(tcKimlikNo.charAt(10)))) {
			result = true;
		} else {
			result = false;
		}
		
		return result;
	}
	
}
