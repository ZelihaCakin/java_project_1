package edu.sau.zelihacakin.rastgelekisiuret.util;

import java.util.Random;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* Türkiye'de geçerli telefon no üretme kuralının içerir
* </p>
*/
public class TelNoUretici {

	public static String telnoUret() {
		Random random = new Random();

		int pivot = random.nextInt((99999999 - 10000000) + 1) + 10000000;

		String pivotString = String.valueOf(pivot);

		return "053".concat(pivotString.toString());
	
	}

}
