package edu.sau.zelihacakin.rastgelekisiuret;

import edu.sau.zelihacakin.rastgelekisiuret.util.IMEIUretici;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* İmei üretme fonksiyonunu çağırır
* </p>
*/
public class IMEINo {
	private String imeiNo;

	public IMEINo() {
		this.imeiNo = IMEIUretici.imeiUret();

	}

	public String getImeiNo() {
		return imeiNo;
	}

}
