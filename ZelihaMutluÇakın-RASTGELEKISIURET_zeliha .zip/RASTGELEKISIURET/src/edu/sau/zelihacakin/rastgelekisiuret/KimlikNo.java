package edu.sau.zelihacakin.rastgelekisiuret;

import edu.sau.zelihacakin.rastgelekisiuret.util.TCKimlikNoUretici;
/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* T.C. kimlik no üretme fonksiyonunu çağırır
* </p>
*/
public class KimlikNo {
	private String tcKimlikNo;

	// constructor
	public KimlikNo() {
		this.tcKimlikNo = TCKimlikNoUretici.tcKimlikNoUret();
	}

	public String getTcKimlikNo() {
		return tcKimlikNo;
	}
}
