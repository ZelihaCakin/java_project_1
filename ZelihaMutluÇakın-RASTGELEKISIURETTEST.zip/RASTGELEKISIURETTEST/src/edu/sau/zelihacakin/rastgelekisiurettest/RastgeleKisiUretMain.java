package edu.sau.zelihacakin.rastgelekisiurettest;

import java.util.Scanner; 

import edu.sau.zelihacakin.rastgelekisiuret.RastgeleKisi; 

/**
*
* @author Zeliha MUTLU ÇAKIN - zeliha.cakin@ogr.sakarya.edu.tr
* @since 22/04/2023
* <p>
* Oluşturulmuş kütüphanenin çalıştırılabilir test dosyasıdır
* </p>
*/
public class RastgeleKisiUretMain {

	public static void main(String[] args) {
		while (true) {
			System.out.println("1- Rastgele Kişi Üret");
		System.out.println("2- Çıkış");
		
		Scanner scanner = new Scanner(System.in);
		
		int input = scanner.nextInt();
		
		if (input == 1) {
			System.out.print("Kişi sayısı giriniz: ");
			int kisiSayisi = scanner.nextInt();
			
			for (int i = 0; i <= kisiSayisi-1; i++) {
				RastgeleKisi rastgeleKisi = new RastgeleKisi();
				rastgeleKisi.rastgeleKisiUret();
			}
			
		} else if (input == 2) {
			System.out.println("Program sonlandırılıyor..");
			return;
		} else {
			System.out.println("Hatalı giriş yaptınız.");
		}
		
			
		}
	}
	
}
